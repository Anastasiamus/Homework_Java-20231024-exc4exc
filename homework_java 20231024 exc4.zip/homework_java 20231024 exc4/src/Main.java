import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        String[] massiv = new String[]{"Polar Bear", "Dog", "White Horse", " Beautiful Butterfly ", " Sky "};
        System.out.println(Arrays.toString(massiv));

        int maxLength = 0;
        int minLength = Integer.MAX_VALUE;
        String longest = " ";
        String smallest = " ";
        for (int i = 0; i < massiv.length; i++) {
            if (massiv[i].length() > maxLength) {
                maxLength = massiv[i].length();
                longest = massiv[i];
            }
        }
        for (int i = 0; i < massiv.length; i++) {
            if (massiv[i].length() < minLength) {
                minLength = massiv[i].length();
                smallest = massiv[i];
            }
        }
        System.out.println(longest);
        System.out.println(smallest);
    }
}


// Задание 4.
//Создайте массив из 5 строк.
// Используя метод length() строк, найдите строку с наибольшей длиной и строк с наименьшей длиной.
//Выведите массив и полученный строки в консоль.